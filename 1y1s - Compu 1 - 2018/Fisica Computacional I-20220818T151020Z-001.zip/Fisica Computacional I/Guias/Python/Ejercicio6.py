
n1=float(input("Ingrese un numero: "))
n2=float(input("Ingrese un numero: "))

if n1>n2:
	mayor=n1
	menor=n2

elif n1<n2:
	mayor=n2
	menor=n1

else:
	menor=n1
	mayor=n2
	mayor=menor

s=n1 + n2		
c=2            
while c<10:   ## la cantidad de numeros usted lo decide
	n=float(input("Ingrese un numero: "))
	if n>mayor:
		mayor=n
	elif n<menor:
		menor=n
	s=s+n
	c=c+1

print s
print c

if mayor==menor:
	print "todos los valores son  iguales"
	promedio = s/c
	print promedio,"promedio"

else:
	promedio = s/c
	print mayor,"mayor"
	print menor,"menor"
	print promedio,"promedio"
		

	
			
		

