
## En el momento en que se enciende la luz verde en un semaforo, un auto en reposo arranca con aceleracion constante a=2.5 [m/s**2].En el     mismo momento, un camion que lleva una velocidad constante Vc=10 [m/s] alcanza el auto y pasa

#a)Calcular la distancia del punto de partida  que el auto alcanza al camion
#b)Calcular la velocidad del auto en ese momento 
#c)Evaluar los metros recorridos en un tiempo en que se encuentran

from pylab import *

#Datos Conocidos
a=2.5  #Aceleracion cte del auto (m/s**2)
Vc=10  #Velocidad cte del camion (m/s)

#Formulas a utilizar
X=(Vc**2*2)/(a) #Formula para sacar la distancia de encuentro en metros 
t=(2*Vc)/(a)    #Formula del tiempo en esa distancia y reemplazar en la sgt formula  
Va=a*t          #Formula para sacar la velocidad del auto en ese momento       
print('La distancia en que el auto alcanza al camion es de',X,'[metros]')  # Respuesta a pregunta a
print('La velocidad del auto en esa distancia es de',Va,'[metros/segundos]')  #Respuesta a pregunta b

#Respuesta a pregunta c
T=[]
X=[]
to=0
while to<=t:
        v=a*to
        vc=10
        x=(a*to**2*0.5)
        print('A los',to,'segundos,el auto ha recorrido',x,'metros')
        X.append(x)
	T.append(to)
	to+=1
	

plot(T,X,"o")
xlabel("tiempo [s]")
ylabel("posicion [m]")
title("X v/s T")
show()
