
e=0
mayores=0
menores=0

while e<10:
	edad=int(input("Ingrese una edad: "))
	if edad<18:
		menores=menores+1
	elif edad>18:
		mayores=mayores+1
	e=e+1

print menores,"menores"
print mayores,"mayores"

