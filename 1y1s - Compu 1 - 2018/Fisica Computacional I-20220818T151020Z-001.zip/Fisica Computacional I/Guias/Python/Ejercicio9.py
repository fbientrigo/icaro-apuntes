

c=1
print c
n=0


c=((4*n+2)*c)/(n+2)
print c


while c<=1e12:
    n=n+1
    c=((4*n+2)*c)/(n+2)
    if c>1e12:
        break
    print c
 
