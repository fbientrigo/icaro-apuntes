a=float(input("Ingrese un valor: "))
b=float(input("Ingrese otro valor: "))

c=a-b

if c<0:
	print a,"es menor que",b

elif c>0:
	print a,"es mayor que",b

else:
	print "los dos valores son iguales"
