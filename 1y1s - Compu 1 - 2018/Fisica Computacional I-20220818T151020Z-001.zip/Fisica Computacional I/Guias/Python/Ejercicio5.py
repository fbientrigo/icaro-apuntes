
s=1

while s<1e10:
	print s
	s = s**2 + 1



