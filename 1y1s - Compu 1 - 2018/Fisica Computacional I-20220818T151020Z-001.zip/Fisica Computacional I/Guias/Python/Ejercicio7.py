
N=50
c=1
print c,"primo"

while c<N:
	c=c+1
	if c%2.0!=0.0 and c%3.0!=0.0 and c%5.0!=0.0 and c%7.0!=0.0 or c==3.0 or c==5.0 or c==7.0 or c==2.0:
		print c,"primo"

