
d=int(input("Ingrese el dia: "))
m=int(input("Ingrese el mes: "))
a=int(input("Ingrese el ano: "))

while d>31 or m>12 or (m==2 and d>=29) or (d>30 and (m==4 or m==6 or m==9 or m==11)):
	print d,"/",m,"/",a
	print "ingreso una fecha no valida, intente otra vez"
	if m==2 and d==29 and a%4==0:
		print "Pero",a,"es ano bisiesto, entonces esta bien"
		break
	d=int(input("Ingrese el dia: "))
	m=int(input("Ingrese el mes: "))
	a=int(input("Ingrese el ano: "))

print d,"/",m,"/",a

