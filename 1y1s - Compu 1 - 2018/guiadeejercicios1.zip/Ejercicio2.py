
a=int(input("Ingrese un numero: "))
d=a

while a>0:
	if a==d:
		a=a-1	 
	elif a%2==0:
	   print a
	   a=a-1
	else:
		a=a-1

