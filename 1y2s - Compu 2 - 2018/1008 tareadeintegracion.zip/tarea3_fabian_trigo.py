from numpy import e,linspace

#Creamos la funcion a integrar
def eu(t):
	return e**(-(t**2))

#Y la funcion que se basa a esta

def E(x,N):
	if x != 0:
		#La funcion solo define los limites
		lim_sup = x
		lim_inf = 0
		
		dt = (lim_sup - lim_inf)/N
		
		suma1 = 0
		for i in range(1,int((N/2)+1)):
			suma1 += eu(lim_inf + (2*i-1)*dt)
		
		suma2 = 0
		for i in range(1,int(N/2)):
			suma2 += eu(lim_inf + 2*i*dt)
		trd = 0.333333333333
		Integral = trd*dt*(eu(dt)+eu(lim_sup)+4*suma1+2*suma2)
		return Integral

print(E(3,3000))

#Ahora a crear un grafico
from matplotlib.pyplot import show, plot

x = linspace(0,3,300)

plot(x,eu(x))
show()
