from numpy import loadtxt,array

datos = loadtxt("velocities.txt")

tiempos = datos[:,0]
velocidades = datos[:,1]

#Regla trapezoide
lim_inf = int(tiempos[0])
lim_sup = int(tiempos[-1])
#Los usaremos más como indices


#Numero de figuras
N = tiempos[-1] - tiempos[0]

#Calculamos el grosor de las fig en base a las var superiores
dt = (lim_sup - lim_inf)/N
#No es muy importante, ya que sea 1, pero es buena idea ponerlo
#para entender que es el area y como practica

#Tenemos los t y velocidades, conocemos los valores pero no la funcion
#Sabemos que el Aerea = b*h = dx * f(lim_inf + i*dx) 
#Area = dx * velocidades[lim_inf + i] hasta el lim_sup

dist = [0]
suma = 0 #Place holder
for i in range(1,100): #sumatoria i=1 hasta i = N-1
	suma += velocidades[i]
	dist.append(suma)


Integral = dt*( 0.5*(velocidades[lim_inf]+velocidades[lim_sup]) + suma  )
dist.append(velocidades[lim_sup]+suma)


print("Distancia recorrida en x fue:" + str(Integral) + "[m]")

#Parte b, un grafico
import matplotlib.pyplot as plt


lineV = plt.plot(tiempos,velocidades,"r", label="velocidades")
lineR = plt.plot(tiempos,dist,"b", label="posicion")
plt.show()
