#Ejercicio 5.2
#a) integral from 0 to 2 of x⁴ - 2x + 1 dx

#definimos la funcion a integrar
def funcion(x):
	return x**4 - 2*x + 1

#Valores basicos
lim_inf = 0
lim_sup = 2

#Slices o numero de figuras
N = 10000

#Base de cada figura
dx = (lim_sup - lim_inf)/N

#Regla Simpson
#calculamos las dos sumatorias
suma1 = 0 #Place holder
for i in range(1, int(N/2)+1):
	suma1 += funcion(lim_inf + (2*i - 1) * dx)

suma2 = 0
for i in range(1,int((N/2))):
	suma2 += funcion(lim_inf + (2*i)*dx)

#Sumatoria final a base de la formula
trd = 0.333333333333
Integral = trd*dx*(funcion(lim_inf)+funcion(lim_sup) + 4*suma1 + 2*suma2)

print("Por Simpson es:" + str(Integral))  

